package com.QuanLyNhanSu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanLyNhanSuApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanLyNhanSuApplication.class, args);
	}

}

